<?php


/*

     [+] Powerd By EZChecker [+]

#######################################                                     ##                                   ##
##    Checker Name : Apple Valid     ##    
##    Coded By : Payz                ##
##    WhatsApp : 082246831089        ##
##                                   ##
#######################################



*/


require 'ez.php';

$ez = new eZChecker;

$banner = $ez->banner();
echo $banner;

$ez->check();




?>